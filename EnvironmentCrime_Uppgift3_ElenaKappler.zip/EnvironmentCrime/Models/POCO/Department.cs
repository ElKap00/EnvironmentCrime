﻿namespace EnvironmentCrime.Models
{
    public class Department
    {
        public required string DepartmentId { get; set; }
        public required string DepartmentName { get; set; }
    }
}
