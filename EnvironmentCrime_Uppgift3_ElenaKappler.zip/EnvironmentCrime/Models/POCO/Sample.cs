﻿namespace EnvironmentCrime.Models
{
	public class Sample
	{
		public int SampleId { get; set; }
		public required string SampleName { get; set; }
		public int ErrandID { get; set; }
	}
}
