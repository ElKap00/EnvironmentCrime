﻿namespace EnvironmentCrime.Models
{
    public class ErrandStatus
    {
        public string StatusId { get; set; }
        public string StatusName { get; set; }
    }
}
