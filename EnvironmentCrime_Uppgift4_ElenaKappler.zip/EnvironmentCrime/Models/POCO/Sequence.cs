﻿namespace EnvironmentCrime.Models
{
	public class Sequence
	{
		public int Id { get; set; }
		public int CurrentValue { get; set; }
	}
}
