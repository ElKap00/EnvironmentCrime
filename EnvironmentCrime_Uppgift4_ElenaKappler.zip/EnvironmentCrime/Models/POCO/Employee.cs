﻿namespace EnvironmentCrime.Models
{
    public class Employee
    {
        public required string EmployeeId { get; set; }
        public required string EmployeeName { get; set; }
        public required string RoleTitle { get; set; }
        public required string DepartmentId { get; set; }
    }
}
